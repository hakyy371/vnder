#!/system/bin/sh
# ----------------------------------------------------
# lvnderrOS Control Center - Bin Installation Script
# Developer: hkyy
# ----------------------------------------------------

# Menampilkan teks logo estetik saat instalasi di AxManager
ui_print " "
ui_print "  ██╗     ██╗   ██╗███╗   ██╗██████╗ ███████╗██████╗ ██████╗ "
ui_print "  ██║     ██║   ██║████╗  ██║██╔══██╗██╔════╝██╔══██╗██╔══██╗"
ui_print "  ██║     ██║   ██║██╔██╗ ██║██║  ██║█████╗  ██████╔╝██████╔╝"
ui_print "  ██║     ╚██╗ ██╔╝██║╚██╗██║██║  ██║██╔══╝  ██╔══██╗██╔══██╗"
ui_print "  ███████╗ ╚████╔╝ ██║ ╚████║██████╔╝███████╗██║  ██║██║  ██║"
ui_print "  ╚══════╝  ╚═══╝  ╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝"
ui_print "                       Control Center v7.0"
ui_print " "
ui_print "- Developer: hkyy"
ui_print "- Environment: AxManager Bin Architecture"
ui_print " "

ui_print "[*] Mendaftarkan skrip tweak ke sistem..."

# 1. Pastikan folder system/bin bawaan zip kamu disalin dengan benar
# (Magisk/KernelSU otomatis menyalin folder 'system' ke sistem Android saat instalasi)

# 2. Berikan izin eksekusi penuh (0755) pada folder biner kustom kamu
if [ -d "$MODPATH/system/bin" ]; then
  ui_print "[*] Mengatur izin akses berkas biner di system/bin..."
  set_perm_recursive "$MODPATH/system/bin" 0 0 0755 0755
fi

# 3. Berikan izin eksekusi penuh pada skrip master boot di latar belakang
if [ -f "$MODPATH/service.sh" ]; then
  set_perm "$MODPATH/service.sh" 0 0 0755
fi

# 4. Berikan izin akses penuh ke folder dashboard webroot agar terbaca WebView
if [ -d "$MODPATH/webroot" ]; then
  set_perm_recursive "$MODPATH/webroot" 0 0 0755 0755
fi

ui_print "[+] Izin direktori & berkas biner sukses dikonfigurasi."
ui_print "[+] lvnderrOS System Bin siap digunakan!"
ui_print " "

iorenice $$ 7 idle
renice -n 19 -p $$